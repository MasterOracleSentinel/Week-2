const numArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// TODO: declare the variable elementAtIndexFive and assign it the value of the element with index number 5 in the array numArray
let elementAtIndexFive = numArray[5]
// This will print the value of variable elementAtIndexFive to the console
console.log('The array element with index 5 is: ', elementAtIndexFive);
