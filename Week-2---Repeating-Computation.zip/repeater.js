//Write a function here to display "Hello World" on the console
function helloWorld()
{
  console.log('Hello World');
}
//Write another function here that will print "Hello World" to the console every 3 seconds
setInterval(helloWorld, 3000);
